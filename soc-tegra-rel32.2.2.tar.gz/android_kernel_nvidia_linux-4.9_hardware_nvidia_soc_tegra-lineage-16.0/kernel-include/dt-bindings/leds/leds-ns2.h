#ifndef _DT_BINDINGS_LEDS_NS2_H
#define _DT_BINDINGS_LEDS_NS2_H

#define NS_V2_LED_OFF	0
#define NS_V2_LED_ON	1
#define NS_V2_LED_SATA	2

#endif
